extends Control

const ItemViewScript = preload("res://scripts/item_view.gd")
const BG := Color("#182320")
const PANEL := Color("#26342e")
const INK := Color("#e9ddbd")

var day := 1
var money := 300
var item_owned := false
var item_on_shelf := false
var bought_honestly := false
var inspection_done := false
var lid_found := false
var shelf_field := 40
var property_strength := 100
var tab := "counter"
var item_view: ItemView
var status_label: Label
var item_info: Label
var money_label: Label
var story_label: Label
var desk_panel: PanelContainer
var shelf_panel: PanelContainer
var action_panel: HBoxContainer
var shelf_buttons: Array[Button] = []
var buy_button: Button
var inspect_button: Button
var sleep_button: Button
var field_button: Button
var tab_counter: Button
var tab_storage: Button

func _ready() -> void:
	build_ui()
	refresh_ui()

func label(text_value: String, font_size := 18) -> Label:
	var node := Label.new()
	node.text = text_value
	node.add_theme_color_override("font_color", INK)
	node.add_theme_font_size_override("font_size", font_size)
	return node

func button(text_value: String, action: Callable) -> Button:
	var node := Button.new()
	node.text = text_value
	node.custom_minimum_size = Vector2(138, 42)
	node.pressed.connect(action)
	return node

func build_ui() -> void:
	var outer := VBoxContainer.new()
	outer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	outer.add_theme_constant_override("separation", 12)
	outer.offset_left = 20
	outer.offset_top = 15
	outer.offset_right = -20
	outer.offset_bottom = -15
	add_child(outer)

	var header := HBoxContainer.new()
	outer.add_child(header)
	header.add_child(label("КУЛЬТУРНЫЙ СЛОЙ  /  1983", 25))
	header.add_spacer(false)
	money_label = label("", 18)
	header.add_child(money_label)

	var navigation := HBoxContainer.new()
	outer.add_child(navigation)
	tab_counter = button("Приёмка", func() -> void: switch_tab("counter"))
	tab_storage = button("Склад", func() -> void: switch_tab("storage"))
	navigation.add_child(tab_counter)
	navigation.add_child(tab_storage)
	navigation.add_child(label("Срез: одна вещь · одна ночь · одно последствие", 14))

	var main_row := HBoxContainer.new()
	main_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(main_row)

	desk_panel = PanelContainer.new()
	desk_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	desk_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_row.add_child(desk_panel)
	var desk := Control.new()
	desk.mouse_filter = Control.MOUSE_FILTER_PASS
	desk_panel.add_child(desk)
	var desk_title := label("ПРИЛАВОК — ПУНКТ ВТОРСЫРЬЯ", 17)
	desk_title.position = Vector2(25, 20)
	desk.add_child(desk_title)
	var drag_hint := label("Тяни самовар мышью. Колесо — поворот.", 15)
	drag_hint.position = Vector2(25, 55)
	desk.add_child(drag_hint)
	item_view = ItemViewScript.new()
	item_view.position = Vector2(170, 125)
	item_view.size = Vector2(210, 220)
	desk.add_child(item_view)

	shelf_panel = PanelContainer.new()
	shelf_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	shelf_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_row.add_child(shelf_panel)
	var shelf_root := VBoxContainer.new()
	shelf_panel.add_child(shelf_root)
	shelf_root.add_child(label("КЛАДОВАЯ / СЕТКА 3 × 2 (для проверки)", 17))
	var grid := GridContainer.new()
	grid.columns = 3
	shelf_root.add_child(grid)
	for i in range(6):
		var index := i
		var slot := button("Пусто", func() -> void: place_item(index))
		slot.custom_minimum_size = Vector2(138, 110)
		grid.add_child(slot)
		shelf_buttons.append(slot)
	field_button = button("Фон склада: 40 %", toggle_field)
	shelf_root.add_child(field_button)
	sleep_button = button("Завершить день → ночь", advance_night)
	shelf_root.add_child(sleep_button)
	shelf_root.add_child(label("При фоне ниже 30 % самовар теряет свойство.", 14))

	var sidebar := VBoxContainer.new()
	sidebar.custom_minimum_size = Vector2(350, 0)
	main_row.add_child(sidebar)
	story_label = label("", 17)
	story_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	story_label.custom_minimum_size = Vector2(350, 175)
	sidebar.add_child(story_label)
	item_info = label("", 16)
	item_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	item_info.custom_minimum_size = Vector2(350, 165)
	sidebar.add_child(item_info)
	action_panel = HBoxContainer.new()
	action_panel.add_theme_constant_override("separation", 8)
	sidebar.add_child(action_panel)
	inspect_button = button("Осмотреть лупой", inspect_item)
	inspect_button.custom_minimum_size.x = 160
	action_panel.add_child(inspect_button)
	buy_button = button("Купить за 90 ₽", buy_item)
	buy_button.custom_minimum_size.x = 160
	action_panel.add_child(buy_button)

	status_label = label("", 16)
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_label.custom_minimum_size.y = 75
	outer.add_child(status_label)

func switch_tab(next_tab: String) -> void:
	tab = next_tab
	refresh_ui()

func inspect_item() -> void:
	if item_owned:
		status_label.text = "Самовар уже куплен. Перейди на склад."
		return
	inspection_done = true
	lid_found = true
	item_view.inspected = true
	item_view.queue_redraw()
	status_label.text = "Лупа: корпус 1961 года, а крышка изготовлена позднее. Таня могла не знать об этом."
	refresh_ui(false)

func buy_item() -> void:
	if item_owned:
		return
	if money < 90:
		status_label.text = "Не хватает денег."
		return
	money -= 90
	item_owned = true
	bought_honestly = lid_found
	status_label.text = "Таня: «Значит, крышка не родная?.. Спасибо, что сказали»." if bought_honestly else "Таня: «Берите. Я думала, он целиком старый»."
	refresh_ui(false)

func place_item(slot: int) -> void:
	if not item_owned:
		status_label.text = "Сначала купи самовар на приёмке."
		return
	item_on_shelf = true
	for i in range(shelf_buttons.size()):
		shelf_buttons[i].text = "☕ Самовар" if i == slot else "Пусто"
	status_label.text = "Самовар поставлен на полку %d. Теперь можно закончить день." % (slot + 1)
	refresh_ui(false)

func toggle_field() -> void:
	shelf_field = 20 if shelf_field == 40 else 40
	status_label.text = "Фон изменён на %d %% (это переключатель для тестирования механики)." % shelf_field
	refresh_ui(false)

func advance_night() -> void:
	if not item_on_shelf:
		status_label.text = "Положи купленный самовар на полку перед ночью."
		return
	if shelf_field < 30:
		# 40-day base lifetime from v0.5, simplified linear nightly decay.
		property_strength = maxi(0, property_strength - 3)
		status_label.text = "02:00 — переслой. Фон низкий: самовар теряет 3 % свойства."
	else:
		status_label.text = "02:00 — переслой. Фона хватает: свойство самовара сохранилось."
	day += 1
	refresh_ui(false)

func refresh_ui(reset_status := true) -> void:
	money_label.text = "День %d   |   %d ₽   |   свойство %d %%" % [day, money, property_strength]
	desk_panel.visible = tab == "counter"
	shelf_panel.visible = tab == "storage"
	action_panel.visible = tab == "counter" and not item_owned
	item_view.visible = not item_owned
	field_button.text = "Фон склада: %d %% (сменить)" % shelf_field
	sleep_button.disabled = not item_on_shelf
	item_info.text = "ВЕЧНЫЙ САМОВАР\nИсторическая база: 90 ₽\nСлоевая база: 150 ₽\nСвойство: всегда горячий (85 °C)\nНорма склада: 30 %%\nСохранность свойства: %d %%\nКрышка: %s" % [property_strength, "новодел обнаружен" if lid_found else "не проверена"]
	story_label.text = "Таня Гусева приносит самовар с Гари. Он горячий, хотя в нём нет воды.\n\nТаня: «Сколько дадите? Мне нужны деньги на снаряжение»." if not item_owned else "Сделка завершена. Перейди в кладовую, поставь самовар на полку и проверь, что произойдёт после ночного переслоя."
	if reset_status:
		status_label.text = "Первый день. Осмотри предмет, затем реши, покупать ли его."
