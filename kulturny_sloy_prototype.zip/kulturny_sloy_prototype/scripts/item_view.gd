extends Control
class_name ItemView

signal moved

var dragging := false
var inspected := false
var has_fake_lid := true
var item_rotation := 0.0
var can_drag := true
var drag_delta := Vector2.ZERO

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	custom_minimum_size = Vector2(210, 220)
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if not can_drag:
		return
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				dragging = true
				drag_delta = event.position
				accept_event()
			else:
				dragging = false
				moved.emit()
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			item_rotation -= 0.18
			queue_redraw()
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			item_rotation += 0.18
			queue_redraw()
	elif event is InputEventMouseMotion and dragging:
		position += event.relative
		moved.emit()

func _draw() -> void:
	var center := size * 0.5
	draw_set_transform(center, item_rotation)
	# Decorative silhouette. Replace later with layered sprite textures.
	draw_ellipse(Vector2(0, 74), Vector2(69, 14), Color("241c15"))
	draw_rect(Rect2(-58, -35, 116, 110), Color("aa683b"))
	draw_rect(Rect2(-50, -29, 100, 98), Color("cc9350"))
	draw_line(Vector2(-59, -18), Vector2(-92, -32), Color("d4ae65"), 11)
	draw_line(Vector2(59, -18), Vector2(92, -32), Color("d4ae65"), 11)
	draw_arc(Vector2(-94, -11), 20, -PI/2, PI/2, 18, Color("d4ae65"), 8)
	draw_arc(Vector2(94, -11), 20, PI/2, PI*1.5, 18, Color("d4ae65"), 8)
	draw_rect(Rect2(-29, -62, 58, 24), Color("c4cbd0") if has_fake_lid else Color("d0a65d"))
	draw_rect(Rect2(-7, -78, 14, 18), Color("c4cbd0") if has_fake_lid else Color("e0b66d"))
	draw_circle(Vector2(0, 4), 19, Color("513521"))
	draw_circle(Vector2(0, 4), 12, Color("d0a96e"))
	draw_line(Vector2(-30, 77), Vector2(-30, 88), Color("d0a65d"), 9)
	draw_line(Vector2(30, 77), Vector2(30, 88), Color("d0a65d"), 9)
	if inspected:
		draw_rect(Rect2(-25, -58, 50, 15), Color("a23f36"), false, 3)
	draw_set_transform(Vector2.ZERO)

func draw_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(33):
		var angle := TAU * float(i) / 32.0
		points.append(center + Vector2(cos(angle) * radii.x, sin(angle) * radii.y))
	draw_colored_polygon(points, color)
